let students = [
{ nim: "5025251000", nama: "Aren Gentong", jurusan: "Informatics", email: "5025251000@student.its.ac.id" },
{ nim: "5025251001", nama: "Mango The Cat", jurusan: "Information Systems", email: "5025251001@student.its.ac.id" }
];

const PER_PAGE = 5;
let currentPage = 1;
let keyword = "";
let editingNim = null;

const form = document.getElementById("student-form");
const fields = {
nim: document.getElementById("nim"),
nama: document.getElementById("nama"),
jurusan: document.getElementById("jurusan"),
email: document.getElementById("email")
};
const formTitle = document.getElementById("form-title");
const btnSimpan = document.getElementById("btn-simpan");
const tbody = document.getElementById("tbody");
const info = document.getElementById("info");
const badge = document.getElementById("badge");
const pagination = document.getElementById("pagination");

const pad = n => String(n).padStart(2, "0");
function esc(text) {
const div = document.createElement("div");
div.textContent = text;
return div.innerHTML;
}

function getFiltered() {
const k = keyword.toLowerCase();
return students.filter(s => s.nama.toLowerCase().includes(k) || s.nim.includes(k));
}

function render() {
const data = getFiltered();
const totalPages = Math.max(1, Math.ceil(data.length / PER_PAGE));
if (currentPage > totalPages) currentPage = totalPages;
const start = (currentPage - 1) * PER_PAGE;
const rows = data.slice(start, start + PER_PAGE);

if (rows.length === 0) {
tbody.innerHTML = '<tr><td colspan="6" class="empty">No matching data found.</td></tr>';
} else {
tbody.innerHTML = rows.map((s, i) => `
<tr>
<td class="num">${pad(start + i + 1)}</td>
<td>${esc(s.nim)}</td>
<td><strong>${esc(s.nama)}</strong></td>
<td><span class="tag">${esc(s.jurusan)}</span></td>
<td><a href="mailto:${esc(s.email)}">${esc(s.email)}</a></td>
<td><div class="actions">
<button class="action edit" data-nim="${esc(s.nim)}">Edit</button>
<button class="action delete" data-nim="${esc(s.nim)}">Delete</button>
</div></td>
</tr>`).join("");
}

badge.textContent = students.length + " Students";
info.textContent = data.length
? `Showing ${start + 1}–${start + rows.length} of ${data.length} students`
: "No data";
renderPagination(totalPages);
}

function renderPagination(totalPages) {
let html = `<button data-page="${currentPage - 1}" ${currentPage === 1 ? "disabled" : ""}>‹</button>`;
for (let p = 1; p <= totalPages; p++) {
html += `<button data-page="${p}" class="${p === currentPage ? "active" : ""}">${p}</button>`;
}
html += `<button data-page="${currentPage + 1}" ${currentPage === totalPages ? "disabled" : ""}>›</button>`;
pagination.innerHTML = html;
}

function setError(name, message) {
const group = fields[name].closest(".form-group");
document.getElementById("err-" + name).textContent = message;
group.classList.toggle("invalid", message !== "");
}

function validate() {
let valid = true;
const nim = fields.nim.value.trim();
const nama = fields.nama.value.trim();
const jurusan = fields.jurusan.value;
const email = fields.email.value.trim();

let msg = "";
if (!nim) msg = "NRP is required.";
else if (!/^\d{4,12}$/.test(nim)) msg = "NRP must be numeric (4–12 digits).";
else if (nim !== editingNim && students.some(s => s.nim === nim)) msg = "NRP is already registered.";
setError("nim", msg);
if (msg) valid = false;

msg = nama.length < 3 ? "Name must be at least 3 characters." : "";
setError("nama", msg);
if (msg) valid = false;

msg = jurusan ? "" : "Please select a major.";
setError("jurusan", msg);
if (msg) valid = false;

msg = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? "" : "Invalid email format.";
setError("email", msg);
if (msg) valid = false;

return valid;
}

function clearForm() {
form.reset();
Object.keys(fields).forEach(n => setError(n, ""));
}

function exitEditMode() {
editingNim = null;
formTitle.textContent = "Add student";
btnSimpan.textContent = "Save data";
clearForm();
}

form.addEventListener("submit", e => {
e.preventDefault();
if (!validate()) return;
const item = {
nim: fields.nim.value.trim(),
nama: fields.nama.value.trim(),
jurusan: fields.jurusan.value,
email: fields.email.value.trim()
};
if (editingNim) {
const idx = students.findIndex(s => s.nim === editingNim);
students[idx] = item;
} else {
students.push(item);
currentPage = Math.ceil(getFiltered().length / PER_PAGE);
}
exitEditMode();
render();
});

document.getElementById("btn-batal").addEventListener("click", exitEditMode);
document.getElementById("btn-reset").addEventListener("click", clearForm);

// ===== Edit & Delete (event delegation) =====
tbody.addEventListener("click", e => {
const btn = e.target.closest("button");
if (!btn) return;
const nim = btn.dataset.nim;
const s = students.find(x => x.nim === nim);
if (btn.classList.contains("edit")) {
editingNim = nim;
fields.nim.value = s.nim;
fields.nama.value = s.nama;
fields.jurusan.value = s.jurusan;
fields.email.value = s.email;
formTitle.textContent = "Edit student";
btnSimpan.textContent = "Save changes";
fields.nama.focus();
}
if (btn.classList.contains("delete")) {
if (confirm(`Delete ${s.nama} (${s.nim})?`)) {
students = students.filter(x => x.nim !== nim);
if (editingNim === nim) exitEditMode();
render();
}
}
});

document.getElementById("search").addEventListener("input", e => {
keyword = e.target.value.trim();
currentPage = 1;
render();
});

pagination.addEventListener("click", e => {
const btn = e.target.closest("button");
if (!btn || btn.disabled) return;
currentPage = Number(btn.dataset.page);
render();
});

render();
